# -*- coding: utf-8 -*-
"""
Created on Thu Dec 28 13:31:20 2017

@author: srika
"""

# Import OpenCV2 for image processing
import cv2
from serial import Serial
#sys.path.append ("\\C:\Users\Python27\Lib\site-packages\cv2.pyd")
import cv2,os,sys,stat

# Import numpy for matrix calculation
import numpy as np

# Import Python Image Library (PIL)
from PIL import Image
# Start capturing video 
vid_cam = cv2.VideoCapture(0)

# Detect object in video stream using Haarcascade Frontal Face
face_detector = cv2.CascadeClassifier('C:\Users\srika\Desktop\data\haarcascades\haarcascade_frontalface_default.xml')
ser = Serial("COM3", 9600)
# For each person, one face id
face_id = ser.readline()
face_id =face_id[3:-1]
print(face_id)
# Initialize sample face image
count = 0
path1= "D:\Internship\data\dataset\User." + str(face_id) 
if not os.path.exists(path1):
#    os.umask(0002)
    os.makedirs (path1,0o777)
os.chmod(path1,stat.S_IWRITE)

# Start looping
while(True):

    # Capture video frame
    _, image_frame = vid_cam.read()

    # Convert frame to grayscale
    gray = cv2.cvtColor(image_frame, cv2.COLOR_BGR2GRAY)

    # Detect frames of different sizes, list of faces rectangles
    faces = face_detector.detectMultiScale(gray, 1.3, 5)

    # Loops for each faces
    for (x,y,w,h) in faces:

        # Crop the image frame into rectangle
        cv2.rectangle(image_frame, (x,y), (x+w,y+h), (255,0,0), 2)
        
        # Increment sample face image
        count += 1

        # Save the captured image into the datasets folder
        cv2.imwrite("dataset/User." + face_id + '/'+"User."+face_id+'.' + str(count) + ".jpg", gray[y:y+h,x:x+w])
        #os.chmod("dataset/User." + face_id + '.' + str(count) + ".jpg",stat.S_IWRITE)
        #cv2.imwrite(path1+"/" + str(face_id) + face_id+'.' + str(count) + ".jpg", gray[y:y+h,x:x+w])
        # Display the video frame, with bounded rectangle on the person's face
        cv2.imshow('frame', image_frame)

    # To stop taking video, press 'q' for at least 100ms
    if cv2.waitKey(100) & 0xFF == ord('q'):
        break

    # If image taken reach 100, stop taking video
    elif count>100:
        break


# Stop video
vid_cam.release()
ser.close()    
recognizer = cv2.face.LBPHFaceRecognizer_create()

# Using prebuilt frontal face training model, for face detection
detector = cv2.CascadeClassifier("C:\Users\srika\Desktop\\data\\haarcascades\\haarcascade_frontalface_default.xml");

# Create method to get the images and label data
def getImagesAndLabels(path):

    # Get all file path
    imagePaths = [os.path.join(path,f) for f in os.listdir(path)] 
    
    # Initialize empty face sample
    faceSamples=[]
    
    # Initialize empty id
    ids = []

    # Loop all the file path
    for imagePath in imagePaths:

        # Get the image and convert it to grayscale
        PIL_img = Image.open(imagePath).convert('L')

        # PIL image to numpy array
        img_numpy = np.array(PIL_img,'uint8')

        # Get the image id
        id = int(os.path.split(imagePath)[-1].split(".")[1])
        #print(id)

        # Get the face from the training images
        faces = detector.detectMultiScale(img_numpy)

        # Loop for each face, append to their respective ID
        for (x,y,w,h) in faces:

            # Add the image to face samples
            faceSamples.append(img_numpy[y:y+h,x:x+w])

            # Add the ID to IDs
            ids.append(id)

    # Pass the face array and IDs array
    return faceSamples,ids

# Get the faces and IDs
faces,ids = getImagesAndLabels(path1)

# Train the model using the faces and IDs
recognizer.train(faces, np.array(ids))

# Save the model into trainer.yml
recognizer.write('trainer/trainer'+face_id+'.yml')
#os.chmod('trainer/trainer'+face_id+'.yml',stat.S_IWRITE)


# Close all started windows
cv2.destroyAllWindows()
